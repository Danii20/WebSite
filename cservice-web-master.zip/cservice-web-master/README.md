# GNUWorld web services

## Setup

Copy the config templates:
```
cp php_includes/config.inc.dist php_includes/config.inc
cp php_includes/cmaster.inc.dist php_includes/cmaster.inc
cp php_includes/blackhole.inc.dist php_includes/blackhole.inc
```
Edit and make necessary changes to the copied configuration files. 


## License

[GNU Public License](http://www.gnu.org/licenses/gpl.txt)

