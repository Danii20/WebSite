DELETE FROM themes WHERE id='5';

INSERT INTO themes VALUES (
-- head
'5',
'Easter',
'01/01',
'12/31',
'31337',
'0',

'easter',

-- left
'ffffd6',
'left_bg.jpg',
'000000',
'000044',
'ef87a5',

'4c4c4c',
'999900',
'0000ff',

-- top
'ffffd6',
'topbott_bg.jpg',
'easter_logo.jpg',

-- bottom (footer)
'ffffd6',
'topbott_bg.jpg',
'000000',
'000044',
'ef87a5',

-- main
'ffffff',
'eegg_bg.jpg',
'000000',
'ffc933',
'000044',
'ef87a5',
'009900',

'990000',
'009900',

-- main/regproc
'999900',
'0000ff',
'0000ff',
'009900',
'eeeeee',

'990099',
'ff0000',

'ff1111',

'009900',
'ff0000',
'bbbbbb',
'ee1166',

'009999',
'eeeeee',
'990000',
'007700',

'ddffdd',
'ffdddd',

-- tables
'ffffd6',
'',
'000000',
'ffffff',
'955800',
'ffffff',
'ffff00',
'aaaaaa',
'ffdddd',
''

);
