DELETE FROM themes WHERE id='4';

INSERT INTO themes VALUES (
-- head
'4',
'Christmas',
'12/23',
'12/25',
'31337',
'0',

'xmas',

-- left
'005500',
'bg_left.jpg',
'ffffff',
'ddddff',
'ff1111',

'4c4c4c',
'ffff00',
'0000ff',

-- top
'747fbf',
'bar_bg.jpg',
'xmas_logo.jpg',

-- bottom (footer)
'747fbf',
'bar_bg.jpg',
'000044',
'0000aa',
'ff1111',

-- main
'ffffff',
'bg_main.jpg',
'000044',
'ffc933',
'0000aa',
'ff1111',
'00ff00',

'990000',
'009900',

-- main/regproc
'ffff00',
'0000ff',
'0000ff',
'00ff00',
'eeeeee',

'990099',
'ff0000',

'ff1111',

'00ff00',
'ff0000',
'ffffff',
'ee1166',

'00ffff',
'eeeeee',
'990000',
'007700',

'ddffdd',
'ffdddd',

-- tables
'747fbf',
'',
'000000',
'ffffff',
'955800',
'ffffff',
'ffff00',
'aaaaaa',
'ffdddd',
''

);
