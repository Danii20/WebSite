DELETE FROM themes WHERE id='1';

INSERT INTO themes VALUES (
-- head
'1',
'default',
'01/01',
'12/31',
'31337',
'0',

'default',

-- left
'60659c',
'',
'000000',
'aaaaaa',
'ffffff',

'aaaaaa',
'000000',
'ffff00',

-- top
'60659c',
'',
'default_logo.jpg',

-- bottom (footer)
'60659c',
'',
'000000',
'aaaaaa',
'ffffff',

-- main
'aaafe4',
'',
'000000',
'505050',
'60659c',
'ff7700',
'ff0000',

'990000',
'009900',

-- main/regproc
'ffff00',
'0000ff',
'0000ff',
'00ff00',
'eeeeee',

'990099',
'ff0000',

'60659c',

'00ff00',
'ff0000',
'ffffff',
'ffeeff',

'00ffff',
'eeeeee',
'990000',
'007700',

'ddffdd',
'ffdddd',

-- tables
'ffffff',
'',
'60659c',
'ffffff',
'dddddd',
'4c4c4c',
'ffff00',
'777777',
'60659c',
''

);
