<?

/* This file is mandatory in personal theme(s) you would eventually provide */

header("Location: ../../../\n\n"); die; ?>
