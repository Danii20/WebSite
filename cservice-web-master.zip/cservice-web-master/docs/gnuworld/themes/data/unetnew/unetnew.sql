DELETE FROM themes WHERE id='6';

INSERT INTO themes VALUES (
-- head
'6',
'unetnew',
'01/01',
'12/31',
'31337',
'0',

'unetnew',


-- left
'456395',
'',
'ffffff',
'e1e1e1',
'ffff00',

'00ff00',
'ffff00',
'ffffff',

-- top
'456395',
'',
'top_logo.jpg',

-- bottom (footer)
'456395',
'',
'ffffff',
'ccccff',
'ff1111',

-- main
'f0f0f0',
'',
'000000',
'505050',
'004400',
'80809A',
'ff0000',

'990000',
'009900',

-- main/regproc
'ffff00',
'0000ff',
'0000ff',
'00ff00',
'eeeeee',

'990099',
'ff0000',

'ff1111',

'00ff00',
'ff0000',
'ffffff',
'ee1166',

'00ffff',
'eeeeee',
'990000',
'007700',

'ddffdd',
'ffdddd',

-- tables
'ffffff',
'',
'000000',
'ffffff',
'003366',
'ffffff',
'ffff00',
'777777',
'ffdddd',
''

);
