DELETE FROM themes WHERE id='2';

INSERT INTO themes VALUES (
-- head
'2',
'Undernet',
'01/01',
'12/31',
'31337',
'0',

'undernet',


-- left
'003151',
'left_bg.gif',
'ffffff',
'ccccff',
'ff1111',

'00ff00',
'ffff00',
'ffffff',

-- top
'a0a0a0',
'',
'top_logo.jpg',

-- bottom (footer)
'003366',
'',
'ffffff',
'ccccff',
'ff1111',

-- main
'a0a0a0',
'',
'000000',
'505050',
'004400',
'ccccff',
'ff0000',

'990000',
'009900',

-- main/regproc
'ffff00',
'0000ff',
'0000ff',
'00ff00',
'eeeeee',

'990099',
'ff0000',

'ff1111',

'00ff00',
'ff0000',
'ffffff',
'ee1166',

'00ffff',
'eeeeee',
'990000',
'007700',

'ddffdd',
'ffdddd',

-- tables
'ffffff',
'',
'000000',
'ffffff',
'003366',
'ffffff',
'ffff00',
'777777',
'ffdddd',
''

);
