DELETE FROM themes WHERE id='3';

INSERT INTO themes VALUES (
-- head
'3',
'Halloween',
'10/31',
'11/01',
'31337',
'0',

'halloween',

-- left
'000000',
'bg01blskl.jpg',
'ffba00',
'ff1111',
'ff9600',

'4c4c4c',
'ffff00',
'0000ff',

-- top
'000000',
'bg01blskl.jpg',
'top_logo.jpg',

-- bottom (footer)
'000000',
'bg01blskl.jpg',
'ff9600',
'ff1111',
'ffff00',

-- main
'000000',
'hbk14.gif',
'ff9600',
'ffc933',
'ff1111',
'ffff00',
'00ff00',

'990000',
'009900',

-- main/regproc
'ffff00',
'0000ff',
'0000ff',
'00ff00',
'eeeeee',

'990099',
'ff0000',

'ff1111',

'00ff00',
'ff0000',
'ffffff',
'ee1166',

'00ffff',
'eeeeee',
'990000',
'007700',

'ddffdd',
'ffdddd',

-- tables
'4c4c4c',
'',
'000000',
'ffffff',
'955800',
'ffffff',
'ffff00',
'aaaaaa',
'ffdddd',
''

);
