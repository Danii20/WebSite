<? include("../../../php_includes/cmaster.inc"); ?>
<!-- $Id: index.php,v 1.4 2002/05/26 01:10:27 nighty Exp $ //-->
<HTML>
<HEAD>
        <TITLE><? echo NETWORK_NAME ?>&nbsp;&nbsp;&nbsp;C h a n n e l&nbsp;&nbsp;&nbsp;S e r v i c e</TITLE>
</HEAD>
<FRAMESET ROWS="60,*,50" frameborder=no framespacing=0 border=0>
        <FRAME SRC="../head.php" NAME="head" SCROLLING=NO NORESIZE=YES>
        <FRAME SRC="main.php" NAME="body" SCROLLING=AUTO NORESIZE=YES>
        <FRAME SRC="../footer.php" NAME="footer" SCROLLING=NO NORESIZE=YES>
        <NOFRAMES>
        <BODY BGCOLOR=#FFFFFF>
                Viewing this page requires a browser capable of displaying frames.
        </BODY>
        </NOFRAMES>
</FRAMESET>
</HTML>
