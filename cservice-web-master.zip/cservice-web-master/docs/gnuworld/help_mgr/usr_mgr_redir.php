<?
	header("Location: usr_mgr.php");
	die;
?>
